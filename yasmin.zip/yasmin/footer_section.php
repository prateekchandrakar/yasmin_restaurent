
<style>
.quickLiksCls{
	list-style: circle !important;
    padding-left: 35px;
}

.quickLiksCls li{
	    line-height: 30px;
}

.quickLiksCls li a{
}

.openHourCls li{
	line-height: 30px;
}

.ourMenuImgFoot li{
	width:33.33%;
	padding:3px; float:left;
}

.ourMenuImgFoot li a img{
	width:100%;
}

.footerCLs{
	color:#fff; padding-top:50px; padding-bottom:50px;
}
.footerCLs h4{
	color:#fff; margin-bottom:25px;
}

.footerCLs p {
	color:#fff;
}


.footerCLs a{
	color:#fff;
}

.footerCLs b{
	color:#fff; font-weight:bold; text-decoration:underline;
}

</style>


<section style="background:#121619;" class="footerCLs">

	<div class="container">
		<div class="row">
			<div class="col-lg-3">
				<h4>Contact Us</h4>
				<p>
				<span style="color:#000;"><u><b>Address</b></u></span> : 
					15 Bishopsmeads Road <br>East Horsley <br>Leatherhead <br>KT24 6RT
				</p>
				<p>
				<span style="color:#000;"><u><b>Phone No</b></u></span> : 
					
					<a href="tel:(01483) 282282">(01483) 282282</a>, <br><a href="tel:(01483) 283283">((01483) 283283</a>
				</p>
				<!--<p>
				<span style="color:#000;"><u><b>Email</b></u></span> : 
					infor@companyname.com
				</p>-->
			</div>
			<div class="col-lg-3">
				<h4>Quick Links</h4>
				<ul class="quickLiksCls">
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="menu_online.php">Menu</a>
					</li>
					<li>
						<a href="">Order Online</a>
					</li>
					<li>
						<a href="">Feedback</a>
					</li>
					<li>
						<a href="book_table_section.php">Table Reservation</a>
					</li>
					<li>
						<a href="contact_us.php">Contact Us</a>
					</li>
				</ul>
			</div>
			<div class="col-lg-3">
				<h4>Open Hours</h4>
				<ul class="openHourCls">
                                <li>Tuesday - Sunday Inc. Bank Holidays</li>
                                <li>12:00 - 2:30pm & 6:00 - 11:00pm</li>
                                <li>Sunday Hours - 12:00pm - 3:00pm & 6:00pm - 10:00pm</li>
                                <li>Sunday Buffet - 12:00 - 3:00pm</li>
                               
                            </ul>
			</div>
			<div class="col-lg-3">
				<h4>Our Menu</h4>
				
				<ul class="ourMenuImgFoot">
					<li>
						<a href="">
							<img src="images/menuimg/biryani_and_rice.jpg">
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/menuimg/traditional_fav_menu.jpg">
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/menuimg/starter_menu.jpg">
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/menuimg/main_course_menu.jpg">
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/menuimg/house_sp_menu.jpg">
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/menuimg/breadmenu.jpg">
						</a>
					</li>
					
					<div style="clear:both;"></div>
					
				</ul>
				
			</div>
		</div>
	</div>

</section>


<style>
.cpCls p{
	
color:#fff; float:left; margin:0px;
}

.cpCls1 {
	
}
</style>

<section style="background:#000;     padding-top: 20px;   padding-bottom: 20px;">

	<div class="container">
		<div class="row">
			
			<div class="col-lg-6">				
				<div class="cpCls"><p>Copyright © <span>Yasmin</span> 2021. All Rights Reserved. </p></div>
			</div>
			<div class="col-lg-6">
				<ul class="social-list cpCls1">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>                                
                                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                            </ul>
							
							
			</div>
			<div style="clear:both;"></div>
		</div>
	</div>

</section>
 

    <!-- FOOTER START -->
    

    <!--SCROLL TOP START-->
    <a href="#0" class="cd-top">Top</a>
    <!--SCROLL TOP START-->