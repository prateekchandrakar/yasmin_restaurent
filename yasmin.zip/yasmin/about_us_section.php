
	
    <!-- CONTENT START -->
    <section style="padding-top:40px;">

        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="home-about">
                        <h5 class="subtitle">About Company Name</h5>
                        <h2>The Secret is at the Table and The Natural Light Food</h2>
                        <p><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam iaculis lorem augue, at quam finibus eget.</strong> </p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam iaculis lorem augue, at quam finibus eget. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam iaculis lorem augue, at quam finibus eget. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam iaculis lorem augue, at quam finibus eget. </p>
                        <b><a href="" class="rmore">Read More</a></b>
                    </div>
                </div>
                <div class="col-lg-6 spacing-md">
                    <div class="row">
                        <div class="col-md-6 col-6">
                            <figure class="grid-img">
                                <img src="images/about2.jpg" alt="" style="box-shadow: 0 10px 15px 0 rgb(3 35 68 / 10%); border-radius:5px;">
                            </figure>
                        </div>
                        <div class="col-md-6 col-6 spacing-sm">
                            <figure class="grid-img">
                                <img src="images/commons/restaurant-9.jpg" alt=""  style="box-shadow: 0 10px 15px 0 rgb(3 35 68 / 10%); border-radius:5px;">
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>
 
